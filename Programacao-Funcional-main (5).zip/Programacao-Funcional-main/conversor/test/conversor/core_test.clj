(ns conversor.core-test
  (:require [clojure.test :refer :all]
            [conversor.core :refer :all]))

(deftest a-test
  (testing "FIXME, I fail."
    (is (= 0 1))))
