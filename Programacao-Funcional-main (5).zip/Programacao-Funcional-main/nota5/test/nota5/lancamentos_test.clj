(ns nota5.lancamentos-test
  (:require [midje.sweet :refer :all]
            [nota5.lancamentos :refer :all]))